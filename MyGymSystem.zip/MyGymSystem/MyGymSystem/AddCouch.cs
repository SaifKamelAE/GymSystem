﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace MyGymSystem
{
    public partial class AddCouch : Form
    {
        public AddCouch()
        {
            InitializeComponent();
            this.FormClosing += OtherForm_FormClosing;
        }

        private void OtherForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Terminate the application
                Application.Exit();
            }
        }

        private void save_Click(object sender, EventArgs e)
        {
            string couchName = name.Text.Trim();
            string couchEmail = cEmail.Text.Trim();
            string couchPhoneNumber = phone.Text.Trim();
            string couchCertificates = cert.Text.Trim();

            // Validate input
            if (string.IsNullOrWhiteSpace(couchName) ||
                string.IsNullOrWhiteSpace(couchEmail) || string.IsNullOrWhiteSpace(couchPhoneNumber) ||
                string.IsNullOrWhiteSpace(couchCertificates))
            {
                MessageBox.Show("Please fill in all fields and ensure membership duration and amount paid are valid numbers.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            int csAge;
            if (!int.TryParse(couchAge.Text.Trim(), out csAge))
            {
                MessageBox.Show("Please enter a valid age.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Establish connection
                using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
                {
                    // Open connection
                    connection.Open();


                    // Insert data into Couch table
                    string couchQuery = "INSERT INTO Coaches (coachName, coachEmail, coachPhoneNumber, coachAge, coachCertificates) " +
                                         "VALUES (@couchName, @couchEmail, @couchPhoneNumber, @couchAge, @couchCertificates); " +
                                         "SELECT SCOPE_IDENTITY();";

                    using (SqlCommand clientCommand = new SqlCommand(couchQuery, connection))
                    {
                        clientCommand.Parameters.AddWithValue("@couchName", couchName);
                        clientCommand.Parameters.AddWithValue("@couchEmail", couchEmail);  // Correct parameter name
                        clientCommand.Parameters.AddWithValue("@couchPhoneNumber", couchPhoneNumber);
                        clientCommand.Parameters.AddWithValue("@couchAge", csAge);
                        clientCommand.Parameters.AddWithValue("@couchCertificates", couchCertificates); // Correct parameter name
                        int clientID = Convert.ToInt32(clientCommand.ExecuteScalar());
                    }

                    // Display success message
                    MessageBox.Show("Data inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Couch couch = new Couch();
                    couch.Show();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                // Handle exception
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void back_Click(object sender, EventArgs e)
        {
            Couch couch = new Couch();
            couch.Show();
            this.Hide();
        }

        private void AddCouch_Load(object sender, EventArgs e)
        {

        }
    }
    }

