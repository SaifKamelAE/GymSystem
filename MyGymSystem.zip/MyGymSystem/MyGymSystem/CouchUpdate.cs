﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class CouchUpdate : Form
    {
        private int coachID;
        private CouchList parentForm;

        public CouchUpdate(int coachID, CouchList parentForm)
        {
            InitializeComponent();
            this.coachID = coachID;
            this.parentForm = parentForm;
            LoadCoachData();
        }

        private void LoadCoachData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
                {
                    connection.Open();
                    string query = "SELECT * FROM Coaches WHERE coachID = @coachID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@coachID", coachID);
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            name.Text = reader["coachName"].ToString();
                            cEmail.Text = reader["coachEmail"].ToString();
                            phone.Text = reader["coachPhoneNumber"].ToString();
                            couchAge.Text = reader["coachAge"].ToString();
                            cert.Text = reader["coachCertificates"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void save_Click(object sender, EventArgs e)
        {
            string coachName = name.Text.Trim();
            string coachEmail = cEmail.Text.Trim();
            string coachPhoneNumber = phone.Text.Trim();
            string coachCertificates = cert.Text.Trim();

            if (string.IsNullOrWhiteSpace(coachName) ||
                string.IsNullOrWhiteSpace(coachEmail) || string.IsNullOrWhiteSpace(coachPhoneNumber) ||
                string.IsNullOrWhiteSpace(coachCertificates))
            {
                MessageBox.Show("Please fill in all fields.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int coachAge;
            if (!int.TryParse(couchAge.Text.Trim(), out coachAge))
            {
                MessageBox.Show("Please enter a valid age.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
                {
                    connection.Open();
                    string updateQuery = @"UPDATE Coaches 
                                           SET coachName = @coachName, 
                                               coachEmail = @coachEmail, 
                                               coachPhoneNumber = @coachPhoneNumber, 
                                               coachAge = @coachAge, 
                                               coachCertificates = @coachCertificates 
                                           WHERE coachID = @coachID";
                    using (SqlCommand command = new SqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@coachName", coachName);
                        command.Parameters.AddWithValue("@coachEmail", coachEmail);
                        command.Parameters.AddWithValue("@coachPhoneNumber", coachPhoneNumber);
                        command.Parameters.AddWithValue("@coachAge", coachAge);
                        command.Parameters.AddWithValue("@coachCertificates", coachCertificates);
                        command.Parameters.AddWithValue("@coachID", coachID);
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Coach data updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            parentForm.LoadCouchData(); // Refresh the data in the CouchList form
                            this.Close(); // Close the current form
                        }
                        else
                        {
                            MessageBox.Show("No coach found with the specified ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
