﻿namespace MyGymSystem
{
    partial class UpdateSession
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.back = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.money = new System.Windows.Forms.TextBox();
            this.privSessions = new System.Windows.Forms.TextBox();
            this.couchid = new System.Windows.Forms.TextBox();
            this.clientid = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(59, 45);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(95, 40);
            this.back.TabIndex = 16;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(687, 597);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(161, 49);
            this.Save.TabIndex = 17;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // money
            // 
            this.money.Location = new System.Drawing.Point(558, 427);
            this.money.Name = "money";
            this.money.Size = new System.Drawing.Size(100, 22);
            this.money.TabIndex = 12;
            // 
            // privSessions
            // 
            this.privSessions.Location = new System.Drawing.Point(558, 383);
            this.privSessions.Name = "privSessions";
            this.privSessions.Size = new System.Drawing.Size(100, 22);
            this.privSessions.TabIndex = 13;
            // 
            // couchid
            // 
            this.couchid.Location = new System.Drawing.Point(558, 324);
            this.couchid.Name = "couchid";
            this.couchid.Size = new System.Drawing.Size(100, 22);
            this.couchid.TabIndex = 14;
            // 
            // clientid
            // 
            this.clientid.Location = new System.Drawing.Point(558, 275);
            this.clientid.Name = "clientid";
            this.clientid.Size = new System.Drawing.Size(100, 22);
            this.clientid.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(357, 433);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "Amount of Money Payed";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(357, 383);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(170, 16);
            this.label4.TabIndex = 10;
            this.label4.Text = "Amount of Private Sessions";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(357, 330);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Couch ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(357, 275);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "Client ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(353, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(305, 58);
            this.label1.TabIndex = 7;
            this.label1.Text = "Add Session";
            // 
            // UpdateSession
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(955, 701);
            this.Controls.Add(this.back);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.money);
            this.Controls.Add(this.privSessions);
            this.Controls.Add(this.couchid);
            this.Controls.Add(this.clientid);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UpdateSession";
            this.Text = "UpdateSession";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.TextBox money;
        private System.Windows.Forms.TextBox privSessions;
        private System.Windows.Forms.TextBox couchid;
        private System.Windows.Forms.TextBox clientid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}