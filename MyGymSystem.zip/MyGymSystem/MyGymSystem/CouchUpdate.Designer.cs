﻿namespace MyGymSystem
{
    partial class CouchUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.save = new System.Windows.Forms.Button();
            this.cert = new System.Windows.Forms.TextBox();
            this.couchAge = new System.Windows.Forms.TextBox();
            this.phone = new System.Windows.Forms.TextBox();
            this.cEmail = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.medicalCon = new System.Windows.Forms.Label();
            this.age = new System.Windows.Forms.Label();
            this.phoneNumber = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.fName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(750, 630);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(144, 70);
            this.save.TabIndex = 60;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // cert
            // 
            this.cert.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cert.Location = new System.Drawing.Point(398, 538);
            this.cert.Name = "cert";
            this.cert.Size = new System.Drawing.Size(466, 36);
            this.cert.TabIndex = 59;
            // 
            // couchAge
            // 
            this.couchAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.couchAge.Location = new System.Drawing.Point(398, 477);
            this.couchAge.Name = "couchAge";
            this.couchAge.Size = new System.Drawing.Size(466, 36);
            this.couchAge.TabIndex = 58;
            // 
            // phone
            // 
            this.phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone.Location = new System.Drawing.Point(398, 416);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(466, 36);
            this.phone.TabIndex = 57;
            // 
            // cEmail
            // 
            this.cEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cEmail.Location = new System.Drawing.Point(398, 368);
            this.cEmail.Name = "cEmail";
            this.cEmail.Size = new System.Drawing.Size(466, 36);
            this.cEmail.TabIndex = 56;
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(398, 313);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(466, 36);
            this.name.TabIndex = 55;
            // 
            // medicalCon
            // 
            this.medicalCon.AutoSize = true;
            this.medicalCon.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medicalCon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.medicalCon.Location = new System.Drawing.Point(214, 538);
            this.medicalCon.Name = "medicalCon";
            this.medicalCon.Size = new System.Drawing.Size(147, 29);
            this.medicalCon.TabIndex = 54;
            this.medicalCon.Text = "Certificates ";
            // 
            // age
            // 
            this.age.AutoSize = true;
            this.age.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.age.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.age.Location = new System.Drawing.Point(214, 477);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(58, 29);
            this.age.TabIndex = 53;
            this.age.Text = "Age";
            // 
            // phoneNumber
            // 
            this.phoneNumber.AutoSize = true;
            this.phoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNumber.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.phoneNumber.Location = new System.Drawing.Point(209, 419);
            this.phoneNumber.Name = "phoneNumber";
            this.phoneNumber.Size = new System.Drawing.Size(183, 29);
            this.phoneNumber.TabIndex = 52;
            this.phoneNumber.Text = "Phone Number";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.email.Location = new System.Drawing.Point(214, 368);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(78, 29);
            this.email.TabIndex = 51;
            this.email.Text = "Email";
            // 
            // fName
            // 
            this.fName.AutoSize = true;
            this.fName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fName.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.fName.Location = new System.Drawing.Point(214, 316);
            this.fName.Name = "fName";
            this.fName.Size = new System.Drawing.Size(81, 29);
            this.fName.TabIndex = 50;
            this.fName.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(388, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(272, 58);
            this.label1.TabIndex = 49;
            this.label1.Text = "Add Couch";
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(63, 80);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(89, 36);
            this.back.TabIndex = 48;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            // 
            // CouchUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1070, 799);
            this.Controls.Add(this.save);
            this.Controls.Add(this.cert);
            this.Controls.Add(this.couchAge);
            this.Controls.Add(this.phone);
            this.Controls.Add(this.cEmail);
            this.Controls.Add(this.name);
            this.Controls.Add(this.medicalCon);
            this.Controls.Add(this.age);
            this.Controls.Add(this.phoneNumber);
            this.Controls.Add(this.email);
            this.Controls.Add(this.fName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.back);
            this.Name = "CouchUpdate";
            this.Text = "CouchUpdate";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button save;
        private System.Windows.Forms.TextBox cert;
        private System.Windows.Forms.TextBox couchAge;
        private System.Windows.Forms.TextBox phone;
        private System.Windows.Forms.TextBox cEmail;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Label medicalCon;
        private System.Windows.Forms.Label age;
        private System.Windows.Forms.Label phoneNumber;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label fName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button back;
    }
}