﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class CouchList : Form
    {
        public CouchList()
        {
            InitializeComponent();
            this.FormClosing += OtherForm_FormClosing;
        }

        private void OtherForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Terminate the application
                Application.Exit();
            }
        }

        public void LoadCouchData()
        {
            ExecuteQueryAndPopulateGridView("SELECT * FROM Coaches");
        }

        private void ExecuteQueryAndPopulateGridView(string query)
        {
            // Establish connection
            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
            {
                try
                {
                    // Open connection
                    connection.Open();

                    // Create a SqlDataAdapter to fetch data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        // Create a DataTable to hold the data
                        DataTable dataTable = new DataTable();

                        // Fill the DataTable with data from the database
                        adapter.Fill(dataTable);

                        // Bind the DataTable to the DataGridView
                        CouchListGrid.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            Couch couch = new Couch();
            couch.Show();
            this.Hide();
        }

        private void search_Click(object sender, EventArgs e)
        {
            string searchText = searchTB.Text.Trim();

            if (!string.IsNullOrWhiteSpace(searchText))
            {
                // Execute a new query based on the search text
                string query = $"SELECT * FROM Coaches WHERE coachName LIKE '%{searchText}%'" +
                    $"OR coachID LIKE '%{searchText}%'";
                ExecuteQueryAndPopulateGridView(query);
            }
            else
            {
                // If search text is empty, load all data
                LoadCouchData();
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            // Check if a row is selected
            if (CouchListGrid.SelectedRows.Count > 0)
            {
                // Get the coach ID from the selected row
                int coachID = Convert.ToInt32(CouchListGrid.SelectedRows[0].Cells["coachID"].Value);

                // Confirm with the user before deleting
                DialogResult result = MessageBox.Show("Are you sure you want to delete this coach?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    DeleteCoach(coachID);
                }
            }
            else
            {
                MessageBox.Show("Please select a coach to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeleteCoach(int coachID)
        {
            // Establish connection
            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
            {
                try
                {
                    // Open connection
                    connection.Open();

                    // Delete the coach record
                    string deleteQuery = "DELETE FROM Coaches WHERE coachID = @coachID";
                    using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                    {
                        deleteCommand.Parameters.AddWithValue("@coachID", coachID);
                        int rowsAffected = deleteCommand.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Coach deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            // Refresh the data displayed in the DataGridView
                            LoadCouchData();
                        }
                        else
                        {
                            MessageBox.Show("No coach found with the specified ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void updateInfo_Click(object sender, EventArgs e)
        {
            if (CouchListGrid.SelectedRows.Count > 0)
            {
                int coachID = Convert.ToInt32(CouchListGrid.SelectedRows[0].Cells["coachID"].Value);
                CouchUpdate updateForm = new CouchUpdate(coachID, this);
                updateForm.Show();
            }
            else
            {
                MessageBox.Show("Please select a coach to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CouchList_Load(object sender, EventArgs e)
        {

        }
    }
}
