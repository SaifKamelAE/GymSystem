﻿namespace MyGymSystem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Client = new System.Windows.Forms.Button();
            this.Couch = new System.Windows.Forms.Button();
            this.privateSessions = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(206, 314);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(588, 58);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome to GYM system";
            // 
            // Client
            // 
            this.Client.Location = new System.Drawing.Point(375, 408);
            this.Client.Name = "Client";
            this.Client.Size = new System.Drawing.Size(277, 82);
            this.Client.TabIndex = 1;
            this.Client.Text = "Clients";
            this.Client.UseVisualStyleBackColor = true;
            this.Client.Click += new System.EventHandler(this.Client_Click);
            // 
            // Couch
            // 
            this.Couch.Location = new System.Drawing.Point(616, 568);
            this.Couch.Name = "Couch";
            this.Couch.Size = new System.Drawing.Size(277, 82);
            this.Couch.TabIndex = 1;
            this.Couch.Text = "Couches";
            this.Couch.UseVisualStyleBackColor = true;
            this.Couch.Click += new System.EventHandler(this.Couch_Click);
            // 
            // privateSessions
            // 
            this.privateSessions.Location = new System.Drawing.Point(121, 556);
            this.privateSessions.Name = "privateSessions";
            this.privateSessions.Size = new System.Drawing.Size(277, 82);
            this.privateSessions.TabIndex = 2;
            this.privateSessions.Text = "Private Sessions";
            this.privateSessions.UseVisualStyleBackColor = true;
            this.privateSessions.Click += new System.EventHandler(this.privateSessions_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::MyGymSystem.Properties.Resources.Fitness;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Location = new System.Drawing.Point(308, 40);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(388, 250);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(953, 697);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.privateSessions);
            this.Controls.Add(this.Couch);
            this.Controls.Add(this.Client);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Client;
        private System.Windows.Forms.Button Couch;
        private System.Windows.Forms.Button privateSessions;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

