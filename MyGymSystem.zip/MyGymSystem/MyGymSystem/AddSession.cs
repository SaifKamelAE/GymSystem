﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class AddSession : Form
    {
        public AddSession()
        {
            InitializeComponent();
            this.FormClosing += OtherForm_FormClosing;
        }

        private void OtherForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Terminate the application
                Application.Exit();
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            // Initialize variables to store parsed values
            int clientID;
            int couchID;
            int privateSessionAmount;
            float amountPaid;

            // Parse input values
            if (!int.TryParse(clientid.Text.Trim(), out clientID))
            {
                MessageBox.Show("Please enter a valid client ID.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(couchid.Text.Trim(), out couchID))
            {
                MessageBox.Show("Please enter a valid couch ID.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(privSessions.Text.Trim(), out privateSessionAmount))
            {
                MessageBox.Show("Please enter a valid number of private sessions.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!float.TryParse(money.Text.Trim(), out amountPaid))
            {
                MessageBox.Show("Please enter a valid amount paid.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Establish connection
                using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
                {
                    // Open connection
                    connection.Open();

                    // Check if the provided Couch ID exists
                    string couchCheckQuery = "SELECT COUNT(*) FROM Coaches WHERE coachID = @coachID";
                    using (SqlCommand couchCheckCommand = new SqlCommand(couchCheckQuery, connection))
                    {
                        couchCheckCommand.Parameters.AddWithValue("@coachID", couchID);
                        int couchCount = (int)couchCheckCommand.ExecuteScalar();
                        if (couchCount == 0)
                        {
                            MessageBox.Show("The provided Couch ID does not exist.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Check if the provided Client ID exists
                    string clientCheckQuery = "SELECT COUNT(*) FROM Clients WHERE clientID = @clientID";
                    using (SqlCommand clientCheckCommand = new SqlCommand(clientCheckQuery, connection))
                    {
                        clientCheckCommand.Parameters.AddWithValue("@clientID", clientID);
                        int clientCount = (int)clientCheckCommand.ExecuteScalar();
                        if (clientCount == 0)
                        {
                            MessageBox.Show("The provided Client ID does not exist.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Insert data into PrivateTraining table
                    string insertQuery = "INSERT INTO PrivateTraining (clientID, coachID, amountOfPrivateDaysTraining, amountOfMoney) " +
                                         "VALUES (@clientID, @coachID, @amountOfPrivateDaysTraining, @amountOfMoney)";
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@clientID", clientID);
                        command.Parameters.AddWithValue("@coachID", couchID);
                        command.Parameters.AddWithValue("@amountOfPrivateDaysTraining", privateSessionAmount);
                        command.Parameters.AddWithValue("@amountOfMoney", amountPaid);
                        command.ExecuteNonQuery();

                        // Display success message
                        MessageBox.Show("Data inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    // Close the form
                    PrivateCouching privateCouching = new PrivateCouching();
                    privateCouching.Show();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                // Handle exception
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    private void back_Click(object sender, EventArgs e)
        {
            PrivateCouching privateCouching = new PrivateCouching();
            privateCouching.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void clientid_TextChanged(object sender, EventArgs e)
        {

        }

        private void couchid_TextChanged(object sender, EventArgs e)
        {

        }

        private void privSessions_TextChanged(object sender, EventArgs e)
        {

        }

        private void money_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

