﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class Couch : Form
    {
        public Couch()
        {
            InitializeComponent(); 
            this.FormClosing += OtherForm_FormClosing;
        }

        private void OtherForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Terminate the application
                Application.Exit();
            }
        }

        private void addClient_Click(object sender, EventArgs e)
        {
            AddCouch couch = new AddCouch();
            couch.Show();
            this.Hide();
        }

        private void couchList_Click(object sender, EventArgs e)
        {
            CouchList couchList = new CouchList();
            couchList.LoadCouchData(); // Load data before showing the form
            couchList.Show();
            this.Hide();
        }

        private void back_Click(object sender, EventArgs e)
        {
            Form1 main = new Form1();
            main.Show();
            this.Hide();
        }
    }
}
