﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class UpdateSession : Form
    {
        private int clientId;

        public UpdateSession(int clientId)
        {
            InitializeComponent();
            this.clientId = clientId;

            // Load existing session details based on clientId
            LoadSessionDetails(clientId);
        }

        private void LoadSessionDetails(int clientId)
        {
            try
            {
                // Establish connection
                using (SqlConnection connection = new SqlConnection("Data Source=Saif\\SQLEXPRESS;Initial Catalog=GymSystem;Integrated Security=True;"))
                {
                    // Open connection
                    connection.Open();

                    // Retrieve session details for the given clientId
                    string query = "SELECT coachID, amountOfPrivateDaysTraining, amountOfMoney FROM PrivateTraining WHERE clientID = @clientId";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@clientId", clientId);
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            couchid.Text = reader["coachID"].ToString();
                            privSessions.Text = reader["amountOfPrivateDaysTraining"].ToString();
                            money.Text = reader["amountOfMoney"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("Session details not found for the provided client ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            // Parse input values
            int couchID = Convert.ToInt32(couchid.Text.Trim());
            int privateSessionAmount = Convert.ToInt32(privSessions.Text.Trim());
            float amountPaid = Convert.ToSingle(money.Text.Trim());

            try
            {
                // Establish connection
                using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
                {
                    // Open connection
                    connection.Open();

                    // Update data in PrivateTraining table
                    string updateQuery = "UPDATE PrivateTraining SET coachID = @coachID, amountOfPrivateDaysTraining = @amountOfPrivateDaysTraining, amountOfMoney = @amountOfMoney WHERE clientID = @clientId";
                    using (SqlCommand command = new SqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@coachID", couchID);
                        command.Parameters.AddWithValue("@amountOfPrivateDaysTraining", privateSessionAmount);
                        command.Parameters.AddWithValue("@amountOfMoney", amountPaid);
                        command.Parameters.AddWithValue("@clientId", clientId);
                        command.ExecuteNonQuery();

                        // Display success message
                        MessageBox.Show("Data updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    // Close the form
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                // Handle exception
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
