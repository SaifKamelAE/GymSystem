﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class PrivateCouchingList : Form
    {
        public PrivateCouchingList()
        {
            InitializeComponent();
            this.FormClosing += OtherForm_FormClosing;
        }

        private void OtherForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Terminate the application
                Application.Exit();
            }
        }

        public void PrivateSessionsList(object sender, DataGridViewCellEventArgs e)
        {
            LoadData();
        }

        public void LoadData()
        {
            // Establish connection
            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
            {
                try
                {
                    // Open connection
                    connection.Open();

                    // Write your SQL query with join operation
                    string query = @"SELECT PT.clientID, C.firstName,C.lastName,PT.coachID, CC.coachName ,PT.amountOfPrivateDaysTraining ,PT.amountOfMoney FROM PrivateTraining PT " +
                                    "INNER JOIN Clients C ON PT.clientID = C.clientID " +
                                    "INNER JOIN Coaches CC ON PT.coachID = CC.coachID";

                    // Create a SqlDataAdapter to fetch data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        // Create a DataTable to hold the data
                        DataTable dataTable = new DataTable();

                        // Fill the DataTable with data from the database
                        adapter.Fill(dataTable);

                        // Bind the DataTable to the DataGridView
                        SessionGrid.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }



        private void deleteSess_Click(object sender, EventArgs e)
        {
            // Get the selected client ID from the DataGridView
            if (SessionGrid.SelectedRows.Count > 0)
            {
                int clientId = Convert.ToInt32(SessionGrid.SelectedRows[0].Cells["clientID"].Value);

                // Confirm deletion with the user
                DialogResult result = MessageBox.Show("Are you sure you want to delete this client?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // Perform the deletion operation
                    DeleteSession(clientId);
                }
            }
            else
            {
                MessageBox.Show("Please select a client to delete.", "No Client Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeleteSession(int clientId)
        {
            // Establish connection
            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
            {
                SqlTransaction transaction = null;

                try
                {
                    // Open connection
                    connection.Open();
                    transaction = connection.BeginTransaction();

                    // Delete record from the database
                    string deleteQuery = "DELETE FROM PrivateTraining WHERE clientID = @clientId";
                    using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection, transaction))
                    {
                        deleteCommand.Parameters.AddWithValue("@clientId", clientId);
                        deleteCommand.ExecuteNonQuery();
                    }

                    // Commit the transaction
                    transaction.Commit();

                    // Remove the selected row from the DataGridView
                    if (SessionGrid.SelectedRows.Count > 0)
                    {
                        SessionGrid.Rows.RemoveAt(SessionGrid.SelectedRows[0].Index);
                    }

                    MessageBox.Show("Client deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    // Roll back the transaction if an error occurs
                    transaction?.Rollback();
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // Close the connection
                    connection.Close();
                }
            }
        }

        private void updateSess_Click(object sender, EventArgs e)
        {
            // Get the selected client ID from the DataGridView
            if (SessionGrid.SelectedRows.Count > 0)
            {
                int clientId = Convert.ToInt32(SessionGrid.SelectedRows[0].Cells["clientID"].Value);

                // Open the UpdateSession form
                UpdateSession updateSession = new UpdateSession(clientId);
                updateSession.ShowDialog();

                // Refresh the DataGridView
                LoadData();
            }
            else
            {
                MessageBox.Show("Please select a client to update.", "No Client Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
