﻿namespace MyGymSystem
{
    partial class Clients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clientList = new System.Windows.Forms.Button();
            this.addClient = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // clientList
            // 
            this.clientList.Location = new System.Drawing.Point(644, 349);
            this.clientList.Name = "clientList";
            this.clientList.Size = new System.Drawing.Size(180, 176);
            this.clientList.TabIndex = 4;
            this.clientList.Text = "Client List";
            this.clientList.UseVisualStyleBackColor = true;
            this.clientList.Click += new System.EventHandler(this.clientList_Click);
            // 
            // addClient
            // 
            this.addClient.Location = new System.Drawing.Point(165, 349);
            this.addClient.Name = "addClient";
            this.addClient.Size = new System.Drawing.Size(180, 176);
            this.addClient.TabIndex = 3;
            this.addClient.Text = "Add Client";
            this.addClient.UseVisualStyleBackColor = true;
            this.addClient.Click += new System.EventHandler(this.addClient_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(403, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 58);
            this.label1.TabIndex = 2;
            this.label1.Text = "Clients";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(45, 30);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(89, 36);
            this.back.TabIndex = 5;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // Clients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(953, 697);
            this.Controls.Add(this.back);
            this.Controls.Add(this.clientList);
            this.Controls.Add(this.addClient);
            this.Controls.Add(this.label1);
            this.Name = "Clients";
            this.Text = "Clients";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button clientList;
        private System.Windows.Forms.Button addClient;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button back;
    }
}