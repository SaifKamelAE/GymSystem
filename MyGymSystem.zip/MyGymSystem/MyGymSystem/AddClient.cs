﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class AddClient : Form
    {
        public AddClient()
        {
            InitializeComponent();
            this.FormClosing += OtherForm_FormClosing;
        }

        private void OtherForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Terminate the application
                Application.Exit();
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            Clients clients = new Clients();
            clients.Show();
            this.Hide();
        }

        private void save_Click(object sender, EventArgs e)
        {

            string cstFirstName = firstName.Text.Trim();
            string cstLastName = lastName.Text.Trim();
            string cstEmail = cEmail.Text.Trim();
            string cstPhoneNumber = phone.Text.Trim();
            string cstMedicalCondition = cstMedCon.Text.Trim();
            string cstMembershipType = memberType.SelectedItem?.ToString();
            int cstMembershipDuration;
            decimal cstPaymentAmount;

            // Validate input
            if (string.IsNullOrWhiteSpace(cstFirstName) || string.IsNullOrWhiteSpace(cstLastName) ||
                string.IsNullOrWhiteSpace(cstEmail) || string.IsNullOrWhiteSpace(cstPhoneNumber) ||
                string.IsNullOrWhiteSpace(cstMedicalCondition) || string.IsNullOrWhiteSpace(cstMembershipType) ||
                !int.TryParse(duration.Text.Trim(), out cstMembershipDuration) ||
                !decimal.TryParse(payAmount.Text.Trim(), out cstPaymentAmount))
            {
                MessageBox.Show("Please fill in all fields and ensure membership duration and amount paid are valid numbers.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            int csAge;
            if (!int.TryParse(cstAge.Text.Trim(), out csAge))
            {
                MessageBox.Show("Please enter a valid age.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Establish connection
                using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
                {
                    // Open connection
                    connection.Open();

                    // Insert data into Clients table
                    string clientQuery = "INSERT INTO Clients (firstName, lastName, email, phoneNumber, age, medicalCondition) " +
                                         "VALUES (@firstName, @lastName, @email, @phoneNumber, @age, @medicalCondition); " +
                                         "SELECT SCOPE_IDENTITY();";
                    using (SqlCommand clientCommand = new SqlCommand(clientQuery, connection))
                    {
                        clientCommand.Parameters.AddWithValue("@firstName", cstFirstName);
                        clientCommand.Parameters.AddWithValue("@lastName", cstLastName);
                        clientCommand.Parameters.AddWithValue("@email", cstEmail);
                        clientCommand.Parameters.AddWithValue("@phoneNumber", cstPhoneNumber);
                        clientCommand.Parameters.AddWithValue("@age", csAge);
                        clientCommand.Parameters.AddWithValue("@medicalCondition", cstMedicalCondition);
                        int clientID = Convert.ToInt32(clientCommand.ExecuteScalar());

                        // Insert data into Memberships table
                        string membershipQuery = "INSERT INTO Memberships (clientID, membershipType, membershipDuration) " +
                                                 "VALUES (@clientID, @membershipType, @membershipDuration)";
                        using (SqlCommand membershipCommand = new SqlCommand(membershipQuery, connection))
                        {
                            membershipCommand.Parameters.AddWithValue("@clientID", clientID);
                            membershipCommand.Parameters.AddWithValue("@membershipType", cstMembershipType);
                            membershipCommand.Parameters.AddWithValue("@membershipDuration", cstMembershipDuration);
                            membershipCommand.ExecuteNonQuery();
                        }

                        // Insert data into Payments table
                        string paymentQuery = "INSERT INTO Payments (clientID, paymentAmount) " +
                                              "VALUES (@clientID, @paymentAmount)";
                        using (SqlCommand paymentCommand = new SqlCommand(paymentQuery, connection))
                        {
                            paymentCommand.Parameters.AddWithValue("@clientID", clientID);
                            paymentCommand.Parameters.AddWithValue("@paymentAmount", cstPaymentAmount);
                            paymentCommand.ExecuteNonQuery();
                        }
                    }

                    // Display success message
                    MessageBox.Show("Data inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clients clients = new Clients();
                    clients.Show();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                // Handle exception
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
