﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class Clients : Form
    {
        public Clients()
        {
            InitializeComponent();
            this.FormClosing += OtherForm_FormClosing;
        }

        private void OtherForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Terminate the application
                Application.Exit();
            }
        }
        private void clientList_Click(object sender, EventArgs e)
        {
            ClientList clientList = new ClientList();
            clientList.ClientListGrid_CellContentClick(sender, null);
            clientList.Show();
            this.Hide();
        }

        private void back_Click(object sender, EventArgs e)
        {
            Form1 main = new Form1();
            main.Show();
            this.Hide();
        }

        private void addClient_Click(object sender, EventArgs e)
        {
            AddClient AddClient = new AddClient();
            AddClient.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
