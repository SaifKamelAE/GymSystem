﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class ClientUpdate : Form
    {
        private int clientId;
        private ClientList parentForm;

        public ClientUpdate(int clientId, ClientList parentForm)
        {
            InitializeComponent();
            this.clientId = clientId;
            this.parentForm = parentForm;
            LoadClientData();
        }

        private void LoadClientData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
                {
                    connection.Open();
                    string query = @"SELECT c.*, m.membershipType, m.membershipDuration, p.paymentAmount 
                             FROM Clients c 
                             INNER JOIN Memberships m ON c.clientID = m.clientID 
                             INNER JOIN Payments p ON c.clientID = p.clientID 
                             WHERE c.clientID = @clientId";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@clientId", clientId);
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            firstName.Text = reader["firstName"].ToString();
                            lastName.Text = reader["lastName"].ToString();
                            cEmail.Text = reader["email"].ToString();
                            phone.Text = reader["phoneNumber"].ToString();
                            cstAge.Text = reader["age"].ToString();
                            cstMedCon.Text = reader["medicalCondition"].ToString();
                            memberType.Text = reader["membershipType"].ToString();
                            duration.Text = reader["membershipDuration"].ToString();
                            payAmount.Text = reader["paymentAmount"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void save_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
                {
                    connection.Open();

                    // Update client information
                    string updateClientQuery = @"UPDATE Clients 
                                         SET firstName = @firstName, lastName = @lastName, 
                                             email = @email, phoneNumber = @phoneNumber, 
                                             age = @age, medicalCondition = @medicalCondition
                                         WHERE clientID = @clientId";

                    using (SqlCommand updateClientCommand = new SqlCommand(updateClientQuery, connection))
                    {
                        updateClientCommand.Parameters.AddWithValue("@firstName", firstName.Text.Trim());
                        updateClientCommand.Parameters.AddWithValue("@lastName", lastName.Text.Trim());
                        updateClientCommand.Parameters.AddWithValue("@email", cEmail.Text.Trim());
                        updateClientCommand.Parameters.AddWithValue("@phoneNumber", phone.Text.Trim());
                        updateClientCommand.Parameters.AddWithValue("@age", int.Parse(cstAge.Text.Trim()));
                        updateClientCommand.Parameters.AddWithValue("@medicalCondition", cstMedCon.Text.Trim());
                        updateClientCommand.Parameters.AddWithValue("@clientId", clientId);

                        updateClientCommand.ExecuteNonQuery();
                    }

                    // Update membership information
                    string updateMembershipQuery = @"UPDATE Memberships 
                                             SET membershipType = @membershipType, membershipDuration = @membershipDuration
                                             WHERE clientID = @clientId";

                    using (SqlCommand updateMembershipCommand = new SqlCommand(updateMembershipQuery, connection))
                    {
                        updateMembershipCommand.Parameters.AddWithValue("@membershipType", memberType.Text.Trim());
                        updateMembershipCommand.Parameters.AddWithValue("@membershipDuration", int.Parse(duration.Text.Trim()));
                        updateMembershipCommand.Parameters.AddWithValue("@clientId", clientId);

                        updateMembershipCommand.ExecuteNonQuery();
                    }

                    // Update payment information
                    string updatePaymentQuery = @"UPDATE Payments 
                                          SET paymentAmount = @paymentAmount
                                          WHERE clientID = @clientId";

                    using (SqlCommand updatePaymentCommand = new SqlCommand(updatePaymentQuery, connection))
                    {
                        updatePaymentCommand.Parameters.AddWithValue("@paymentAmount", decimal.Parse(payAmount.Text.Trim()));
                        updatePaymentCommand.Parameters.AddWithValue("@clientId", clientId);

                        updatePaymentCommand.ExecuteNonQuery();
                    }

                    MessageBox.Show("Client data updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Update the DataGridView in the parent form
                    parentForm.LoadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
