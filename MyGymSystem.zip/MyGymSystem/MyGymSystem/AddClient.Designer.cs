﻿namespace MyGymSystem
{
    partial class AddClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.back = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.fName = new System.Windows.Forms.Label();
            this.lName = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.phoneNumber = new System.Windows.Forms.Label();
            this.age = new System.Windows.Forms.Label();
            this.medicalCon = new System.Windows.Forms.Label();
            this.membershipType = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.paymentAmount = new System.Windows.Forms.Label();
            this.firstName = new System.Windows.Forms.TextBox();
            this.lastName = new System.Windows.Forms.TextBox();
            this.cEmail = new System.Windows.Forms.TextBox();
            this.phone = new System.Windows.Forms.TextBox();
            this.cstAge = new System.Windows.Forms.TextBox();
            this.cstMedCon = new System.Windows.Forms.TextBox();
            this.memberType = new System.Windows.Forms.ComboBox();
            this.duration = new System.Windows.Forms.TextBox();
            this.payAmount = new System.Windows.Forms.TextBox();
            this.save = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // back
            // 
            this.back.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.back.Location = new System.Drawing.Point(43, 37);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(89, 36);
            this.back.TabIndex = 6;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(368, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(255, 58);
            this.label1.TabIndex = 7;
            this.label1.Text = "Add Client";
            // 
            // fName
            // 
            this.fName.AutoSize = true;
            this.fName.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.fName.Location = new System.Drawing.Point(173, 221);
            this.fName.Name = "fName";
            this.fName.Size = new System.Drawing.Size(72, 16);
            this.fName.TabIndex = 8;
            this.fName.Text = "First Name";
            // 
            // lName
            // 
            this.lName.AutoSize = true;
            this.lName.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lName.Location = new System.Drawing.Point(173, 259);
            this.lName.Name = "lName";
            this.lName.Size = new System.Drawing.Size(72, 16);
            this.lName.TabIndex = 9;
            this.lName.Text = "Last Name";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.email.Location = new System.Drawing.Point(173, 293);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(41, 16);
            this.email.TabIndex = 10;
            this.email.Text = "Email";
            // 
            // phoneNumber
            // 
            this.phoneNumber.AutoSize = true;
            this.phoneNumber.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.phoneNumber.Location = new System.Drawing.Point(173, 327);
            this.phoneNumber.Name = "phoneNumber";
            this.phoneNumber.Size = new System.Drawing.Size(97, 16);
            this.phoneNumber.TabIndex = 11;
            this.phoneNumber.Text = "Phone Number";
            // 
            // age
            // 
            this.age.AutoSize = true;
            this.age.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.age.Location = new System.Drawing.Point(173, 362);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(32, 16);
            this.age.TabIndex = 12;
            this.age.Text = "Age";
            // 
            // medicalCon
            // 
            this.medicalCon.AutoSize = true;
            this.medicalCon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.medicalCon.Location = new System.Drawing.Point(173, 400);
            this.medicalCon.Name = "medicalCon";
            this.medicalCon.Size = new System.Drawing.Size(114, 16);
            this.medicalCon.TabIndex = 13;
            this.medicalCon.Text = "Medical Condition";
            // 
            // membershipType
            // 
            this.membershipType.AutoSize = true;
            this.membershipType.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.membershipType.Location = new System.Drawing.Point(173, 431);
            this.membershipType.Name = "membershipType";
            this.membershipType.Size = new System.Drawing.Size(119, 16);
            this.membershipType.TabIndex = 14;
            this.membershipType.Text = "MemberShip Type";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(173, 472);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 16);
            this.label9.TabIndex = 15;
            this.label9.Text = "MemberShip Duration";
            // 
            // paymentAmount
            // 
            this.paymentAmount.AutoSize = true;
            this.paymentAmount.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.paymentAmount.Location = new System.Drawing.Point(173, 518);
            this.paymentAmount.Name = "paymentAmount";
            this.paymentAmount.Size = new System.Drawing.Size(108, 16);
            this.paymentAmount.TabIndex = 16;
            this.paymentAmount.Text = "Payment Amount";
            // 
            // firstName
            // 
            this.firstName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.firstName.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.firstName.Location = new System.Drawing.Point(357, 218);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(373, 22);
            this.firstName.TabIndex = 17;
            // 
            // lastName
            // 
            this.lastName.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lastName.Location = new System.Drawing.Point(357, 259);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(373, 22);
            this.lastName.TabIndex = 18;
            // 
            // cEmail
            // 
            this.cEmail.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cEmail.Location = new System.Drawing.Point(357, 293);
            this.cEmail.Name = "cEmail";
            this.cEmail.Size = new System.Drawing.Size(373, 22);
            this.cEmail.TabIndex = 19;
            // 
            // phone
            // 
            this.phone.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.phone.Location = new System.Drawing.Point(357, 327);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(373, 22);
            this.phone.TabIndex = 20;
            // 
            // cstAge
            // 
            this.cstAge.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cstAge.Location = new System.Drawing.Point(357, 362);
            this.cstAge.Name = "cstAge";
            this.cstAge.Size = new System.Drawing.Size(373, 22);
            this.cstAge.TabIndex = 21;
            // 
            // cstMedCon
            // 
            this.cstMedCon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cstMedCon.Location = new System.Drawing.Point(357, 397);
            this.cstMedCon.Name = "cstMedCon";
            this.cstMedCon.Size = new System.Drawing.Size(373, 22);
            this.cstMedCon.TabIndex = 22;
            // 
            // memberType
            // 
            this.memberType.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.memberType.FormattingEnabled = true;
            this.memberType.Items.AddRange(new object[] {
            "Platinum",
            "Gold",
            "Silver",
            "Common"});
            this.memberType.Location = new System.Drawing.Point(357, 431);
            this.memberType.Name = "memberType";
            this.memberType.Size = new System.Drawing.Size(373, 24);
            this.memberType.TabIndex = 23;
            // 
            // duration
            // 
            this.duration.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.duration.Location = new System.Drawing.Point(357, 472);
            this.duration.Name = "duration";
            this.duration.Size = new System.Drawing.Size(373, 22);
            this.duration.TabIndex = 24;
            // 
            // payAmount
            // 
            this.payAmount.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.payAmount.Location = new System.Drawing.Point(357, 512);
            this.payAmount.Name = "payAmount";
            this.payAmount.Size = new System.Drawing.Size(373, 22);
            this.payAmount.TabIndex = 25;
            // 
            // save
            // 
            this.save.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.save.Location = new System.Drawing.Point(730, 587);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(144, 70);
            this.save.TabIndex = 26;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // AddClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(953, 697);
            this.Controls.Add(this.save);
            this.Controls.Add(this.payAmount);
            this.Controls.Add(this.duration);
            this.Controls.Add(this.memberType);
            this.Controls.Add(this.cstMedCon);
            this.Controls.Add(this.cstAge);
            this.Controls.Add(this.phone);
            this.Controls.Add(this.cEmail);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.firstName);
            this.Controls.Add(this.paymentAmount);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.membershipType);
            this.Controls.Add(this.medicalCon);
            this.Controls.Add(this.age);
            this.Controls.Add(this.phoneNumber);
            this.Controls.Add(this.email);
            this.Controls.Add(this.lName);
            this.Controls.Add(this.fName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.back);
            this.Name = "AddClient";
            this.Text = "AddClient";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label fName;
        private System.Windows.Forms.Label lName;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label phoneNumber;
        private System.Windows.Forms.Label age;
        private System.Windows.Forms.Label medicalCon;
        private System.Windows.Forms.Label membershipType;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label paymentAmount;
        private System.Windows.Forms.TextBox firstName;
        private System.Windows.Forms.TextBox lastName;
        private System.Windows.Forms.TextBox cEmail;
        private System.Windows.Forms.TextBox phone;
        private System.Windows.Forms.TextBox cstAge;
        private System.Windows.Forms.TextBox cstMedCon;
        private System.Windows.Forms.ComboBox memberType;
        private System.Windows.Forms.TextBox duration;
        private System.Windows.Forms.TextBox payAmount;
        private System.Windows.Forms.Button save;
    }
}