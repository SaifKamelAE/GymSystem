﻿namespace MyGymSystem
{
    partial class ClientList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Button();
            this.clientsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gymSystemDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gymSystemDataSet = new MyGymSystem.GymSystemDataSet();
            this.clientsTableAdapter = new MyGymSystem.GymSystemDataSetTableAdapters.ClientsTableAdapter();
            this.membershipsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.membershipsTableAdapter = new MyGymSystem.GymSystemDataSetTableAdapters.MembershipsTableAdapter();
            this.ClientListGrid = new System.Windows.Forms.DataGridView();
            this.search = new System.Windows.Forms.Button();
            this.searchTB = new System.Windows.Forms.TextBox();
            this.delete = new System.Windows.Forms.Button();
            this.updateInfo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymSystemDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymSystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.membershipsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClientListGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(436, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 58);
            this.label1.TabIndex = 0;
            this.label1.Text = "Client List";
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(33, 36);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(89, 36);
            this.back.TabIndex = 6;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // clientsBindingSource
            // 
            this.clientsBindingSource.DataMember = "Clients";
            this.clientsBindingSource.DataSource = this.gymSystemDataSetBindingSource;
            // 
            // gymSystemDataSetBindingSource
            // 
            this.gymSystemDataSetBindingSource.DataSource = this.gymSystemDataSet;
            this.gymSystemDataSetBindingSource.Position = 0;
            // 
            // gymSystemDataSet
            // 
            this.gymSystemDataSet.DataSetName = "GymSystemDataSet";
            this.gymSystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // clientsTableAdapter
            // 
            this.clientsTableAdapter.ClearBeforeFill = true;
            // 
            // membershipsBindingSource
            // 
            this.membershipsBindingSource.DataMember = "Memberships";
            this.membershipsBindingSource.DataSource = this.gymSystemDataSet;
            // 
            // membershipsTableAdapter
            // 
            this.membershipsTableAdapter.ClearBeforeFill = true;
            // 
            // ClientListGrid
            // 
            this.ClientListGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ClientListGrid.Location = new System.Drawing.Point(136, 199);
            this.ClientListGrid.Name = "ClientListGrid";
            this.ClientListGrid.RowHeadersWidth = 51;
            this.ClientListGrid.RowTemplate.Height = 24;
            this.ClientListGrid.Size = new System.Drawing.Size(853, 355);
            this.ClientListGrid.TabIndex = 7;
            // 
            // search
            // 
            this.search.Location = new System.Drawing.Point(919, 161);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(72, 24);
            this.search.TabIndex = 8;
            this.search.Text = "Search";
            this.search.UseVisualStyleBackColor = true;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // searchTB
            // 
            this.searchTB.Location = new System.Drawing.Point(776, 162);
            this.searchTB.Name = "searchTB";
            this.searchTB.Size = new System.Drawing.Size(137, 22);
            this.searchTB.TabIndex = 9;
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(249, 588);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(166, 66);
            this.delete.TabIndex = 10;
            this.delete.Text = "Delete";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // updateInfo
            // 
            this.updateInfo.Location = new System.Drawing.Point(698, 588);
            this.updateInfo.Name = "updateInfo";
            this.updateInfo.Size = new System.Drawing.Size(166, 66);
            this.updateInfo.TabIndex = 10;
            this.updateInfo.Text = "Update";
            this.updateInfo.UseVisualStyleBackColor = true;
            this.updateInfo.Click += new System.EventHandler(this.updateInfo_Click);
            // 
            // ClientList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1130, 697);
            this.Controls.Add(this.updateInfo);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.searchTB);
            this.Controls.Add(this.search);
            this.Controls.Add(this.ClientListGrid);
            this.Controls.Add(this.back);
            this.Controls.Add(this.label1);
            this.Name = "ClientList";
            this.Text = "ClientList";
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymSystemDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymSystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.membershipsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClientListGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.BindingSource gymSystemDataSetBindingSource;
        private GymSystemDataSet gymSystemDataSet;
        private System.Windows.Forms.BindingSource clientsBindingSource;
        private GymSystemDataSetTableAdapters.ClientsTableAdapter clientsTableAdapter;
        private System.Windows.Forms.BindingSource membershipsBindingSource;
        private GymSystemDataSetTableAdapters.MembershipsTableAdapter membershipsTableAdapter;
        private System.Windows.Forms.DataGridView ClientListGrid;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.TextBox searchTB;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button updateInfo;
    }
}