﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class PrivateCouching : Form
    {
        public PrivateCouching()
        {
            InitializeComponent();
            this.FormClosing += OtherForm_FormClosing;
        }

        private void OtherForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Terminate the application
                Application.Exit();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PrivateCouchingList privateCouchingList = new PrivateCouchingList();
            privateCouchingList.PrivateSessionsList(sender, null);
            privateCouchingList.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddSession addSession = new AddSession();
            addSession.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 main = new Form1();
            main.Show();
            this.Hide();
        }

 
    }
}
