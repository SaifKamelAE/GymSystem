﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace MyGymSystem
{
    public partial class ClientList : Form
    {
        public ClientList()
        {
            InitializeComponent();
            this.FormClosing += OtherForm_FormClosing;
        }

        private void OtherForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Terminate the application
                Application.Exit();
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            Clients clients = new Clients();
            clients.Show();
            this.Hide();
        }

        public void ClientListGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadData();
        }

        public void LoadData()
        {
            // Establish connection
            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
            {
                try
                {
                    // Open connection
                    connection.Open();

                    // Write your SQL query with join operation
                    string query = @"SELECT 
                                    c.clientID, 
                                    c.firstName, 
                                    c.lastName, 
                                    c.email, 
                                    c.phoneNumber, 
                                    c.age, 
                                    c.medicalCondition, 
                                    m.membershipType, 
                                    m.membershipDuration, 
                                    p.paymentAmount
                                FROM 
                                    Clients c
                                INNER JOIN 
                                    Memberships m ON c.clientID = m.clientID
                                INNER JOIN 
                                    Payments p ON c.clientID = p.clientID";

                    // Create a SqlDataAdapter to fetch data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        // Create a DataTable to hold the data
                        DataTable dataTable = new DataTable();

                        // Fill the DataTable with data from the database
                        adapter.Fill(dataTable);

                        // Bind the DataTable to the DataGridView
                        ClientListGrid.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            string searchText = searchTB.Text.Trim();

            // Execute a new query based on the search text
            if (!string.IsNullOrWhiteSpace(searchText))
            {
                string query = $@"SELECT 
                                    c.clientID, 
                                    c.firstName, 
                                    c.lastName, 
                                    c.email, 
                                    c.phoneNumber, 
                                    c.age, 
                                    c.medicalCondition, 
                                    m.membershipType, 
                                    m.membershipDuration, 
                                    p.paymentAmount
                                FROM 
                                    Clients c
                                INNER JOIN 
                                    Memberships m ON c.clientID = m.clientID
                                INNER JOIN 
                                    Payments p ON c.clientID = p.clientID
                                WHERE 
                                    c.clientID LIKE '%{searchText}%' OR
                                    c.firstName LIKE '%{searchText}%' OR
                                    c.lastName LIKE '%{searchText}%';";

                ExecuteQueryAndUpdateGridView(query);
            }
            else
            {
                // If search text is empty, load all data
                LoadData();
            }
        }

        private void ExecuteQueryAndUpdateGridView(string query)
        {
            // Establish connection
            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
            {
                try
                {
                    // Open connection
                    connection.Open();

                    // Create a SqlDataAdapter to fetch data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        // Create a DataTable to hold the data
                        DataTable dataTable = new DataTable();

                        // Fill the DataTable with data from the database
                        adapter.Fill(dataTable);

                        // Bind the DataTable to the DataGridView
                        ClientListGrid.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            // Get the selected client ID from the DataGridView
            if (ClientListGrid.SelectedRows.Count > 0)
            {
                int clientId = Convert.ToInt32(ClientListGrid.SelectedRows[0].Cells["clientID"].Value);

                // Confirm deletion with the user
                DialogResult result = MessageBox.Show("Are you sure you want to delete this client?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // Perform the deletion operation
                    DeleteClient(clientId);
                }
            }
            else
            {
                MessageBox.Show("Please select a client to delete.", "No Client Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeleteClient(int clientId)
        {
            // Establish connection
            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\GymSystem.mdf;Integrated Security=True"))
            {
                SqlTransaction transaction = null;

                try
                {
                    // Open connection
                    connection.Open();
                    transaction = connection.BeginTransaction();

                    // Delete related membership records
                    string deleteMembershipQuery = "DELETE FROM Memberships WHERE clientID = @clientId";
                    using (SqlCommand deleteMembershipCommand = new SqlCommand(deleteMembershipQuery, connection, transaction))
                    {
                        deleteMembershipCommand.Parameters.AddWithValue("@clientId", clientId);
                        deleteMembershipCommand.ExecuteNonQuery();
                    }

                    // Delete related payment records
                    string deletePaymentQuery = "DELETE FROM Payments WHERE clientID = @clientId";
                    using (SqlCommand deletePaymentCommand = new SqlCommand(deletePaymentQuery, connection, transaction))
                    {
                        deletePaymentCommand.Parameters.AddWithValue("@clientId", clientId);
                        deletePaymentCommand.ExecuteNonQuery();
                    }

                    // Delete the client record
                    string deleteClientQuery = "DELETE FROM Clients WHERE clientID = @clientId";
                    using (SqlCommand deleteClientCommand = new SqlCommand(deleteClientQuery, connection, transaction))
                    {
                        deleteClientCommand.Parameters.AddWithValue("@clientId", clientId);
                        int rowsAffected = deleteClientCommand.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Client deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            // Commit the transaction if successful
                            transaction.Commit();
                            // Refresh the data displayed in the DataGridView
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("No client found with the specified ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Roll back the transaction if an error occurs
                    transaction?.Rollback();
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // Close the connection
                    connection.Close();
                }
            }
        }



        private void updateInfo_Click(object sender, EventArgs e)
        {
            if (ClientListGrid.SelectedRows.Count > 0)
            {
                int clientId = Convert.ToInt32(ClientListGrid.SelectedRows[0].Cells["clientID"].Value);
                ClientUpdate updateForm = new ClientUpdate(clientId, this);
                updateForm.Show();
            }
            else
            {
                MessageBox.Show("Please select a client to update.", "No Client Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}
